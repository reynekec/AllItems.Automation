$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

dotnet run --project "examples/SelectorDemo.Wpf/SelectorDemo.Wpf.csproj"
