﻿using System.Windows;

namespace SelectorDemo.Wpf;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    private BrowserWindow? _contentWindow;

    public MainWindow()
    {
        InitializeComponent();
    }

    private async void NavigateButton_Click(object sender, RoutedEventArgs e)
    {
        var startWithDebug = StartWithDebugCheckBox.IsChecked == true;

        // If content window doesn't exist or is closed, create a new one with the URL
        if (_contentWindow == null || !_contentWindow.IsLoaded)
        {
            _contentWindow = new BrowserWindow(UrlTextBox.Text, startWithDebug);
            _contentWindow.Show();
        }
        else
        {
            if (startWithDebug)
            {
                await _contentWindow.EnableDebugCaptureAsync();
            }

            // If window already exists, navigate to new URL
            _contentWindow.NavigateTo(UrlTextBox.Text);
        }
    }
}
