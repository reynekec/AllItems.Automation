from PIL import Image, ImageDraw

# Define colors
CORNFLOWER_BLUE = (100, 149, 237)
DARK_BLUE = (65, 105, 225)
WHITE = (255, 255, 255)
LIGHT_GRAY = (240, 240, 240)

# Create a 256x256 icon
size = 256
img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
draw = ImageDraw.Draw(img)

# Draw browser window
margin = 20
# Window background
draw.rectangle([margin, margin, size-margin, size-margin], fill=WHITE, outline=CORNFLOWER_BLUE, width=3)

# Title bar
title_bar_height = 35
draw.rectangle([margin, margin, size-margin, margin+title_bar_height], fill=CORNFLOWER_BLUE)

# Address bar area
addr_bar_y = margin + title_bar_height + 10
draw.rectangle([margin+10, addr_bar_y, size-margin-10, addr_bar_y+25], fill=LIGHT_GRAY, outline=DARK_BLUE, width=1)

# Draw a simple magnifying glass (search/selection symbol)
center_x = size // 2
center_y = size // 2 + 30

# Circle (magnifying glass lens)
lens_radius = 30
draw.ellipse([center_x-lens_radius, center_y-lens_radius, center_x+lens_radius, center_y+lens_radius], 
             outline=CORNFLOWER_BLUE, width=4)

# Handle (magnifying glass stick)
handle_start_x = center_x + lens_radius - 10
handle_start_y = center_y + lens_radius - 10
handle_end_x = center_x + lens_radius + 25
handle_end_y = center_y + lens_radius + 25
draw.line([(handle_start_x, handle_start_y), (handle_end_x, handle_end_y)], fill=CORNFLOWER_BLUE, width=4)

# Save as PNG
png_path = 'SelectorDemo.png'
img.save(png_path, 'PNG')
print(f"Created {png_path}")

# Create smaller ICO (convert to ICO format - Windows expects certain sizes)
ico_sizes = [(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)]
ico_images = []

for ico_size in ico_sizes:
    resized = img.resize(ico_size, Image.Resampling.LANCZOS)
    ico_images.append(resized)

ico_path = 'SelectorDemo.ico'
ico_images[0].save(ico_path, 'ICO', sizes=[(img_sz[0], img_sz[1]) for img_sz in ico_sizes],
                    append_images=ico_images[1:])
print(f"Created {ico_path}")

print("\nIcon files created successfully!")
print(f"PNG: {png_path} (256x256)")
print(f"ICO: {ico_path} (multiple sizes: 16, 32, 48, 64, 128, 256)")
