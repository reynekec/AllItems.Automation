﻿using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Threading;

namespace SelectorDemo.Wpf;

/// <summary>
/// Interaction logic for App.xaml
/// </summary>
public partial class App : Application
{
	private static readonly string LogDirectory = Path.Combine(
		Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
		"AllItems",
		"SelectorDemo",
		"logs");

	private static readonly string CrashLogPath = Path.Combine(LogDirectory, "wpf-crash.log");

	protected override void OnStartup(StartupEventArgs e)
	{
		Directory.CreateDirectory(LogDirectory);

		DispatcherUnhandledException += OnDispatcherUnhandledException;
		AppDomain.CurrentDomain.UnhandledException += OnUnhandledException;
		TaskScheduler.UnobservedTaskException += OnUnobservedTaskException;

		base.OnStartup(e);
	}

	private static void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
	{
		Log("DispatcherUnhandledException", e.Exception);
		MessageBox.Show(
			"The app hit an unexpected error. A crash log was written to:\n" + CrashLogPath,
			"Selector Demo Error",
			MessageBoxButton.OK,
			MessageBoxImage.Error);
		e.Handled = true;
	}

	private static void OnUnhandledException(object sender, UnhandledExceptionEventArgs e)
	{
		var ex = e.ExceptionObject as Exception;
		Log("AppDomainUnhandledException", ex ?? new Exception("Unknown unhandled exception"));
	}

	private static void OnUnobservedTaskException(object? sender, UnobservedTaskExceptionEventArgs e)
	{
		Log("UnobservedTaskException", e.Exception);
		e.SetObserved();
	}

	private static void Log(string source, Exception ex)
	{
		var sb = new StringBuilder();
		sb.AppendLine("============================================================");
		sb.AppendLine($"Timestamp: {DateTime.UtcNow:O}");
		sb.AppendLine($"Source: {source}");
		sb.AppendLine($"Message: {ex.Message}");
		sb.AppendLine("StackTrace:");
		sb.AppendLine(ex.StackTrace);

		if (ex.InnerException is not null)
		{
			sb.AppendLine("InnerException:");
			sb.AppendLine(ex.InnerException.ToString());
		}

		File.AppendAllText(CrashLogPath, sb.ToString() + Environment.NewLine);
	}
}

