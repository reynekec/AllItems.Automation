using System.IO;
using System.Text.Json;
using System.Threading;
using System.Windows;
using Microsoft.Web.WebView2.Core;

namespace SelectorDemo.Wpf;

/// <summary>
/// Interaction logic for ContentWindow.xaml
/// </summary>
public partial class ContentWindow : Window
{
    private readonly string _webViewUserDataPrimary = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "AllItems",
        "SelectorDemo",
        "WebView2");

    private readonly string _webViewUserDataFallback = Path.Combine(
        Path.GetTempPath(),
        "AllItems",
        "SelectorDemo",
        "WebView2");

    private TaskCompletionSource<SelectionResult>? _inAppSelectionCompletion;
    private bool _webMessageHooked;
    private readonly List<CoreWebView2Frame> _allKnownFrames = [];
    private volatile bool _selectionActive;

    private string? _initialUrl;

    public ContentWindow()
    {
        InitializeComponent();
        Loaded += ContentWindow_Loaded;
    }

    public ContentWindow(string url) : this()
    {
        _initialUrl = url;
    }

    private async void ContentWindow_Loaded(object sender, RoutedEventArgs e)
    {
        await EnsureBrowserReadyAsync();
        if (!string.IsNullOrEmpty(_initialUrl))
        {
            NavigateTo(_initialUrl);
        }
    }

    private async Task EnsureBrowserReadyAsync()
    {
        if (BrowserView.CoreWebView2 is not null)
        {
            return;
        }

        try
        {
            Directory.CreateDirectory(_webViewUserDataPrimary);
            var primaryEnvironment = await CoreWebView2Environment.CreateAsync(userDataFolder: _webViewUserDataPrimary);
            await BrowserView.EnsureCoreWebView2Async(primaryEnvironment);
        }
        catch (UnauthorizedAccessException)
        {
            Directory.CreateDirectory(_webViewUserDataFallback);
            var fallbackEnvironment = await CoreWebView2Environment.CreateAsync(userDataFolder: _webViewUserDataFallback);
            await BrowserView.EnsureCoreWebView2Async(fallbackEnvironment);
            StatusTextBox.Text = "WebView2 profile folder access was denied. Using fallback temp profile.";
        }

        BrowserView.CoreWebView2!.Settings.AreDefaultContextMenusEnabled = true;

        if (!_webMessageHooked)
        {
            BrowserView.CoreWebView2.WebMessageReceived += CoreWebView2_WebMessageReceived;
            BrowserView.CoreWebView2.FrameCreated += CoreWebView2_FrameCreated;
            _webMessageHooked = true;
        }
    }

    private void CoreWebView2_WebMessageReceived(object? sender, CoreWebView2WebMessageReceivedEventArgs e)
        => HandleWebMessage(e.WebMessageAsJson);

    private void CoreWebView2_FrameCreated(object? sender, CoreWebView2FrameCreatedEventArgs e)
    {
        var frame = e.Frame;

        lock (_allKnownFrames)
        {
            _allKnownFrames.Add(frame);
        }

        frame.Destroyed += (_, _) =>
        {
            lock (_allKnownFrames) { _allKnownFrames.Remove(frame); }
        };

        frame.WebMessageReceived += (_, args) => HandleWebMessage(args.WebMessageAsJson);

        if (_selectionActive)
        {
            _ = TryInjectFrameScriptAsync(frame);
        }
    }

    private static async Task TryInjectFrameScriptAsync(CoreWebView2Frame frame)
    {
        try { await frame.ExecuteScriptAsync(BuildFrameScript()); }
        catch { }
    }

    private void HandleWebMessage(string json)
    {
        if (_inAppSelectionCompletion is null)
        {
            return;
        }

        try
        {
            using var doc = JsonDocument.Parse(json);
            var root = doc.RootElement;

            if (!root.TryGetProperty("type", out var typeNode) ||
                typeNode.ValueKind != JsonValueKind.String ||
                typeNode.GetString() != "selector-capture-result")
            {
                return;
            }

            var result = ReadSelectionResult(root);
            _inAppSelectionCompletion.TrySetResult(result);
        }
        catch (Exception ex)
        {
            _inAppSelectionCompletion?.TrySetResult(
                new SelectionResult("error", ex.Message, string.Empty, string.Empty, string.Empty));
        }
    }

    public async void NavigateTo(string url)
    {
        try
        {
            await EnsureBrowserReadyAsync();
            BrowserView.CoreWebView2!.Navigate(url);
            StatusTextBox.Text = "Navigated. Use Start Selection (In-App) to pick an element.";
        }
        catch (Exception ex)
        {
            StatusTextBox.Text = $"Navigation error: {ex.Message}";
        }
    }

    private async void StartInAppSelectionButton_Click(object sender, RoutedEventArgs e)
    {
        await StartInAppSelectionAsync();
    }

    private async Task StartInAppSelectionAsync()
    {
        // Find the button dynamically
        var startButton = FindName("StartInAppSelectionButton") as System.Windows.Controls.Button;
        if (startButton != null)
            startButton.IsEnabled = false;

        StatusTextBox.Text = "Selection active — click any element, including inside embedded frames (Esc to cancel).";

        try
        {
            await EnsureBrowserReadyAsync();
            CssSelectorTextBox.Text = string.Empty;
            XPathSelectorTextBox.Text = string.Empty;

            _selectionActive = true;
            _inAppSelectionCompletion = new TaskCompletionSource<SelectionResult>(TaskCreationOptions.RunContinuationsAsynchronously);

            // Inject the main-frame capture script.
            await BrowserView.CoreWebView2!.ExecuteScriptAsync(BuildMainFrameScript());

            // Inject a capture script into every iframe already tracked.
            List<CoreWebView2Frame> snapshot;
            lock (_allKnownFrames) { snapshot = [.. _allKnownFrames]; }

            foreach (var frame in snapshot)
            {
                try { await frame.ExecuteScriptAsync(BuildFrameScript()); }
                catch { /* frame may already be gone */ }
            }

            using var timeout = new CancellationTokenSource(TimeSpan.FromMinutes(2));
            var result = await _inAppSelectionCompletion.Task.WaitAsync(timeout.Token);

            if (result.Status == "selected")
            {
                CssSelectorTextBox.Text = result.CssSelector;
                XPathSelectorTextBox.Text = result.XPathSelector;

                var statusMsg = "Element selected.";
                if (!string.IsNullOrWhiteSpace(result.FrameUrl))
                {
                    statusMsg += $"  (inside frame: {result.FrameUrl})";
                }

                StatusTextBox.Text = statusMsg;
            }
            else
            {
                StatusTextBox.Text = string.IsNullOrWhiteSpace(result.Message)
                    ? "Selection was cancelled."
                    : result.Message;
            }
        }
        catch (OperationCanceledException)
        {
            StatusTextBox.Text = "Timed out waiting for a click. Selection cancelled.";
        }
        catch (Exception ex)
        {
            StatusTextBox.Text = $"In-app selection failed: {ex.Message}";
        }
        finally
        {
            _selectionActive = false;
            _inAppSelectionCompletion = null;
            if (startButton != null)
                startButton.IsEnabled = true;
            await CleanupSelectionAsync();
        }
    }

    private async Task CleanupSelectionAsync()
    {
        var cleanup = BuildCleanupScript();

        try
        {
            if (BrowserView.CoreWebView2 is not null)
            {
                await BrowserView.CoreWebView2.ExecuteScriptAsync(cleanup);
            }
        }
        catch { }

        List<CoreWebView2Frame> snapshot;
        lock (_allKnownFrames) { snapshot = [.. _allKnownFrames]; }

        foreach (var frame in snapshot)
        {
            try { await frame.ExecuteScriptAsync(cleanup); }
            catch { }
        }
    }

    private static string BuildMainFrameScript()
    {
        return @"(() => {
    function sendResult(result) {
        if (window.chrome && window.chrome.webview) {
            window.chrome.webview.postMessage(Object.assign({ type: 'selector-capture-result' }, result));
        }
    }

    function escapeCss(value) {
        if (!value) return '';
        return value.replace(/([!""#$%&'()*+,./:;<=>?@[\\\]^`{|}~])/g, '\\\\$1');
    }

    function cssOf(el) {
        if (el.id) {
            return '#' + escapeCss(el.id);
        }
        const parts = [];
        let current = el;
        while (current && current.nodeType === Node.ELEMENT_NODE) {
            let part = current.tagName.toLowerCase();
            if (current.id) {
                part += '#' + escapeCss(current.id);
                parts.unshift(part);
                break;
            }
            const siblings = current.parentElement
                ? Array.from(current.parentElement.children).filter(x => x.tagName === current.tagName)
                : [];
            if (siblings.length > 1) {
                part += ':nth-of-type(' + (siblings.indexOf(current) + 1) + ')';
            }
            parts.unshift(part);
            current = current.parentElement;
            if (parts.length > 8) break;
        }
        return parts.join(' > ');
    }

    function xpathOf(el) {
        const parts = [];
        let current = el;
        while (current && current.nodeType === Node.ELEMENT_NODE) {
            let index = 1;
            let sibling = current.previousElementSibling;
            while (sibling) {
                if (sibling.tagName === current.tagName) index++;
                sibling = sibling.previousElementSibling;
            }
            parts.unshift(current.tagName.toLowerCase() + '[' + index + ']');
            current = current.parentElement;
        }
        return '/' + parts.join('/');
    }

    if (window.__selectorCaptureActive) {
        sendResult({ status: 'busy', message: 'Selection is already active.' });
        return;
    }
    window.__selectorCaptureActive = true;

    let highlight = null, shield = null;

    function swallow(e) {
        if (!e) return;
        if (typeof e.preventDefault === 'function') e.preventDefault();
        if (typeof e.stopPropagation === 'function') e.stopPropagation();
        if (typeof e.stopImmediatePropagation === 'function') e.stopImmediatePropagation();
    }

    function removeHighlight() {
        if (highlight) { highlight.remove(); highlight = null; }
    }

    function showHighlight(target) {
        if (!target || target === document.documentElement || target === document.body) {
            removeHighlight(); return;
        }
        removeHighlight();
        const rect = target.getBoundingClientRect();
        highlight = document.createElement('div');
        highlight.style.position = 'fixed';
        highlight.style.left = Math.max(rect.left, 0) + 'px';
        highlight.style.top = Math.max(rect.top, 0) + 'px';
        highlight.style.width = Math.max(rect.width, 2) + 'px';
        highlight.style.height = Math.max(rect.height, 2) + 'px';
        highlight.style.border = '2px solid #2ec27e';
        highlight.style.background = 'rgba(46, 194, 126, 0.16)';
        highlight.style.pointerEvents = 'none';
        highlight.style.zIndex = '2147483647';
        document.documentElement.appendChild(highlight);
    }

    function getElementAtPoint(x, y) {
        shield.style.display = 'none';
        const el = document.elementFromPoint(x, y);
        shield.style.display = 'block';
        return el;
    }

    function isFrameEl(el) {
        const tag = el?.tagName?.toLowerCase() ?? '';
        return tag === 'iframe' || tag === 'frame';
    }

    function cleanup() {
        if (shield) { shield.remove(); shield = null; }
        removeHighlight();
        window.__selectorCaptureActive = false;
        window.__selectorCaptureCleanup = null;
        document.removeEventListener('keydown', onKeyDown, true);
        window.removeEventListener('message', onChildMessage);
    }
    window.__selectorCaptureCleanup = cleanup;

    function onPointerMove(e) {
        swallow(e);
        const el = getElementAtPoint(e.clientX, e.clientY);
        if (isFrameEl(el)) {
            // Let pointer events pass through to the iframe's own capture shield.
            shield.style.pointerEvents = 'none';
        } else {
            shield.style.pointerEvents = 'auto';
        }
        showHighlight(el);
    }

    function onPointerDown(e) { swallow(e); }
    function onPointerUp(e) { swallow(e); }

    function onClick(e) {
        swallow(e);
        const el = getElementAtPoint(e.clientX, e.clientY);
        if (!el || el === document.documentElement || el === document.body) {
            cleanup();
            sendResult({ status: 'cancelled', message: 'No selectable element at click point.' });
            return;
        }
        // Clicks on iframe shells are handled by the injected frame script.
        if (isFrameEl(el)) return;
        cleanup();
        sendResult({ status: 'selected', cssSelector: cssOf(el), xpathSelector: xpathOf(el) });
    }

    function onChildMessage(e) {
        if (!e.data) return;
        if (e.data.type === 'capture-pointer-left-frame' && shield) {
            shield.style.pointerEvents = 'auto';
        }
        if (e.data.type === 'capture-cancel') {
            cleanup();
            sendResult({ status: 'cancelled', message: 'Selection cancelled.' });
        }
    }

    function onKeyDown(e) {
        if (e.key !== 'Escape') return;
        swallow(e);
        cleanup();
        sendResult({ status: 'cancelled', message: 'Selection cancelled by user.' });
    }

    shield = document.createElement('div');
    shield.style.position = 'fixed';
    shield.style.left = '0';
    shield.style.top = '0';
    shield.style.width = '100vw';
    shield.style.height = '100vh';
    shield.style.zIndex = '2147483646';
    shield.style.cursor = 'crosshair';
    shield.style.background = 'rgba(0,0,0,0)';
    shield.style.pointerEvents = 'auto';
    shield.setAttribute('aria-hidden', 'true');

    shield.addEventListener('pointermove', onPointerMove, true);
    shield.addEventListener('pointerdown', onPointerDown, true);
    shield.addEventListener('pointerup', onPointerUp, true);
    shield.addEventListener('click', onClick, true);
    document.addEventListener('keydown', onKeyDown, true);
    window.addEventListener('message', onChildMessage);

    document.documentElement.appendChild(shield);
})();";
    }

    private static string BuildFrameScript()
    {
        return @"(() => {
    function sendResult(result) {
        if (window.chrome && window.chrome.webview) {
            window.chrome.webview.postMessage(Object.assign({ type: 'selector-capture-result' }, result));
        }
    }

    function escapeCss(value) {
        if (!value) return '';
        return value.replace(/([!""#$%&'()*+,./:;<=>?@[\\\]^`{|}~])/g, '\\\\$1');
    }

    function cssOf(el) {
        if (el.id) return '#' + escapeCss(el.id);
        const parts = [];
        let current = el;
        while (current && current.nodeType === Node.ELEMENT_NODE) {
            let part = current.tagName.toLowerCase();
            if (current.id) {
                part += '#' + escapeCss(current.id);
                parts.unshift(part);
                break;
            }
            const siblings = current.parentElement
                ? Array.from(current.parentElement.children).filter(x => x.tagName === current.tagName)
                : [];
            if (siblings.length > 1) part += ':nth-of-type(' + (siblings.indexOf(current) + 1) + ')';
            parts.unshift(part);
            current = current.parentElement;
            if (parts.length > 8) break;
        }
        return parts.join(' > ');
    }

    function xpathOf(el) {
        const parts = [];
        let current = el;
        while (current && current.nodeType === Node.ELEMENT_NODE) {
            let index = 1;
            let sibling = current.previousElementSibling;
            while (sibling) {
                if (sibling.tagName === current.tagName) index++;
                sibling = sibling.previousElementSibling;
            }
            parts.unshift(current.tagName.toLowerCase() + '[' + index + ']');
            current = current.parentElement;
        }
        return '/' + parts.join('/');
    }

    if (window.__selectorCaptureActive) return;
    window.__selectorCaptureActive = true;

    let highlight = null, shield = null;

    function swallow(e) {
        if (!e) return;
        if (typeof e.preventDefault === 'function') e.preventDefault();
        if (typeof e.stopPropagation === 'function') e.stopPropagation();
        if (typeof e.stopImmediatePropagation === 'function') e.stopImmediatePropagation();
    }

    function removeHighlight() {
        if (highlight) { highlight.remove(); highlight = null; }
    }

    function showHighlight(target) {
        if (!target || target === document.documentElement || target === document.body) {
            removeHighlight(); return;
        }
        removeHighlight();
        const rect = target.getBoundingClientRect();
        highlight = document.createElement('div');
        highlight.style.position = 'fixed';
        highlight.style.left = Math.max(rect.left, 0) + 'px';
        highlight.style.top = Math.max(rect.top, 0) + 'px';
        highlight.style.width = Math.max(rect.width, 2) + 'px';
        highlight.style.height = Math.max(rect.height, 2) + 'px';
        highlight.style.border = '2px solid #2ec27e';
        highlight.style.background = 'rgba(46, 194, 126, 0.16)';
        highlight.style.pointerEvents = 'none';
        highlight.style.zIndex = '2147483647';
        document.documentElement.appendChild(highlight);
    }

    function cleanup() {
        if (shield) { shield.remove(); shield = null; }
        removeHighlight();
        window.__selectorCaptureActive = false;
        window.__selectorCaptureCleanup = null;
        document.removeEventListener('keydown', onKeyDown, true);
    }
    window.__selectorCaptureCleanup = cleanup;

    function onPointerMove(e) {
        swallow(e);
        shield.style.display = 'none';
        const el = document.elementFromPoint(e.clientX, e.clientY);
        shield.style.display = 'block';
        showHighlight(el);
    }

    function onPointerLeave() {
        removeHighlight();
        try { window.parent.postMessage({ type: 'capture-pointer-left-frame' }, '*'); } catch (err) {}
    }

    function onPointerDown(e) { swallow(e); }
    function onPointerUp(e) { swallow(e); }

    function onClick(e) {
        swallow(e);
        shield.style.display = 'none';
        const el = document.elementFromPoint(e.clientX, e.clientY);
        shield.style.display = 'block';
        if (!el || el === document.documentElement || el === document.body) {
            cleanup();
            sendResult({ status: 'cancelled', message: 'No selectable element.' });
            return;
        }
        const frameUrl = (typeof window !== 'undefined' && window.location) ? window.location.href : '';
        cleanup();
        sendResult({ status: 'selected', cssSelector: cssOf(el), xpathSelector: xpathOf(el), frameUrl: frameUrl });
    }

    function onKeyDown(e) {
        if (e.key !== 'Escape') return;
        swallow(e);
        cleanup();
        try { window.parent.postMessage({ type: 'capture-cancel' }, '*'); } catch (err) {}
        sendResult({ status: 'cancelled', message: 'Selection cancelled.' });
    }

    shield = document.createElement('div');
    shield.style.position = 'fixed';
    shield.style.left = '0';
    shield.style.top = '0';
    shield.style.width = '100vw';
    shield.style.height = '100vh';
    shield.style.zIndex = '2147483646';
    shield.style.cursor = 'crosshair';
    shield.style.background = 'rgba(0,0,0,0)';
    shield.style.pointerEvents = 'auto';
    shield.setAttribute('aria-hidden', 'true');

    shield.addEventListener('pointermove', onPointerMove, true);
    shield.addEventListener('pointerleave', onPointerLeave, true);
    shield.addEventListener('pointerdown', onPointerDown, true);
    shield.addEventListener('pointerup', onPointerUp, true);
    shield.addEventListener('click', onClick, true);
    document.addEventListener('keydown', onKeyDown, true);

    document.documentElement.appendChild(shield);
})();";
    }

    private static string BuildCleanupScript()
        => "if (typeof window.__selectorCaptureCleanup === 'function') { window.__selectorCaptureCleanup(); }";

    private static SelectionResult ReadSelectionResult(JsonElement element)
    {
        string GetString(string propertyName)
        {
            if (element.TryGetProperty(propertyName, out var value) && value.ValueKind == JsonValueKind.String)
            {
                return value.GetString() ?? string.Empty;
            }
            return string.Empty;
        }

        return new SelectionResult(
            GetString("status"),
            GetString("message"),
            GetString("cssSelector"),
            GetString("xpathSelector"),
            GetString("frameUrl"));
    }

    private sealed record SelectionResult(string Status, string Message, string CssSelector, string XPathSelector, string FrameUrl);
}
