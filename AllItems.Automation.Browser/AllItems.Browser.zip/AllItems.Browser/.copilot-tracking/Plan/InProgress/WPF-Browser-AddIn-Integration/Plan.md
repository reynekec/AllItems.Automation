# WPF-Browser-AddIn-Integration Plan

## Problem Statement

The WPF application (AllItems) needs to integrate with web pages to intelligently select and extract unique selectors for HTML elements. When HTML contains duplicate IDs or CSS classes, the system must find a stable, unique selector that reliably identifies the exact element across page reloads and minor DOM structure changes.

The solution requires:
1. A browser extension (AllItems.Browser.AddIn) running in Chromium-based browsers
2. Two-way communication between WPF and the extension via native messaging
3. A "click-to-select" UI that allows users to choose elements on a webpage
4. An intelligent selector engine that generates unique CSS and XPath selectors
5. Conflict resolution when duplicates exist (using ancestor-based selectors)

---

## Proposed Approach

### Architecture Overview

```
WPF Application (Windows)
       ↓ (native messaging)
   Chrome Extensions Host (Windows)
       ↓
AllItems.Browser.AddIn Extension (Chromium)
       ↓ (content scripts + UI)
   Webpage DOM
```

### Key Design Decisions

1. **Native Messaging Protocol**  
   - WPF acts as a native messaging host for Chrome/Chromium extensions
   - Extension sends messages to WPF via `chrome.runtime.sendNativeMessage()`
   - WPF receives messages via stdin and responds via stdout
   - Enables secure, sandboxed communication without network overhead

2. **Two-Part Selector Strategy**  
   - **Primary**: CSS selector using ID, class, or attribute combinations with ancestor scoping
   - **Fallback**: XPath that includes ancestor chain to ensure uniqueness
   - Both selectors are validated to match exactly one element before returning to WPF

3. **Ancestor-Based Conflict Resolution**  
   - When an element's ID/class is not unique, climb the DOM tree
   - Build selectors like: `#parent-id > div.child-class` or `div.container > .item`
   - Continue until the selector is guaranteed to match only the selected element

4. **Click-and-Confirm Flow**  
   - User clicks "Select Element" button in WPF
   - Extension injection activates click handler on page
   - User clicks target element
   - Extension highlights the selected element and shows its selector
   - User confirms selection (or retries by clicking another element)
   - Selector is sent back to WPF via native messaging

5. **Shadow DOM & iFrame Support**  
   - Selectors can include iframe paths: `iframe[src="..."] >>> #id`
   - Shadow DOM elements use `>>>` combinator notation where applicable
   - XPath adapted for piercing shadow boundaries

6. **Validation Strategy**  
   - After generating a selector, run `document.querySelectorAll(selector)` to verify uniqueness
   - If multiple matches → automatically extend selector with ancestor info
   - If no matches → alert user (page structure issue)
   - Continue refinement until exactly 1 match found

---

## Phases

### Phase 1: Project Setup & Architecture
- [x] Create extension project structure (manifest v3, folders, build tools)
- [x] Set up package.json and build/dev tools (webpack or esbuild)
- [x] Create manifest.json for Chromium extension with appropriate permissions
- [x] Define native messaging protocol (message schemas, error codes)
- [x] Create placeholder WPF integration documentation
- [x] Set up git repo with .gitignore for build outputs

**Deliverables:**
- Project folder structure: `/src`, `/public`, `/build`, `/tests`, `/docs`
- manifest.json with permissions for activeTab, scripting, nativeMessaging
- Native messaging protocol specification (JSON message format)
- README with setup instructions

---

### Phase 2: Selector Engine Core
- [ ] Create `SelectorGenerator` class: extracts ID, class, attribute signatures
- [ ] Create `UniquenessTester` class: validates selectors with `querySelectorAll`
- [ ] Create `AncestorResolver` class: climbs DOM to build unique ancestor chains
- [ ] Implement CSS selector builder with ancestor scoping logic
- [ ] Implement XPath selector builder as fallback
- [ ] Create selector priority ranking (prefer CSS, shorter = better)
- [ ] Unit tests for selector generation across various DOM patterns

**Deliverables:**
- `/src/selector-engine/` folder with core modules
- Selector generation algorithm handling:
  - Simple ID/class selectors
  - Duplicate ID/class with ancestor resolution
  - Attribute-based selectors ([data-*, type, role, etc])
  - Nested elements and pseudo-elements
- Test suite covering common HTML patterns
- JSDoc/comment documentation for each function

---

### Phase 3: Content Script & Element Selection UI
- [ ] Create content script that injects into active tab
- [ ] Implement click event handler that captures target element
- [ ] Add overlay/highlight UI to show selected element visually
- [ ] Create selector display UI (shows CSS + XPath selectors)
- [ ] Add "confirm" and "retry" buttons in popup
- [ ] Handle edge cases (disabled elements, form inputs, etc)
- [ ] Ensure script works correctly across shadow DOM and iframes

**Deliverables:**
- `/src/content-script.js` with element selection logic
- Overlay styles for highlighting selected element
- Popup HTML/CSS with selector display and confirmation buttons
- Scripts to inject content script when extension is activated
- Error handling for special element types

---

### Phase 4: Native Messaging Bridge
- [ ] Create background script as message handler
- [ ] Implement message listener from WPF (via `chrome.runtime.onNativeMessage`)
- [ ] Create message sender to WPF with selected selector data
- [ ] Add message validation and error handling
- [ ] Log all messages for debugging
- [ ] Handle extension activation/deactivation states

**Deliverables:**
- `/src/background.js` with native messaging handlers
- Message protocol implementation (request/response validation)
- Error message schemas (timeout expired, user cancelled, etc)
- Logging utility for troubleshooting communication

---

### Phase 5: UI/UX & Popup Interface
- [ ] Design extension popup UI (icon, layout, styling)
- [ ] Create popup.html with status display
- [ ] Implement popup.js to:
  - Show "Start Selection" button
  - Display currently selected element info
  - Show extracted selectors (CSS + XPath)
  - Provide "Copy" button for selectors
  - Display "Ready to Send to WPF" confirmation
- [ ] Add keyboard shortcut for quick access (Ctrl+Shift+E or similar)
- [ ] Style popup consistently (light/dark mode support optional)

**Deliverables:**
- `/src/popup.html`, `/src/popup.css`, `/src/popup.js`
- Smooth UX for element selection → confirmation → sending
- Visual feedback during each state (idle, selecting, confirmed, sending)

---

### Phase 6: Integration with WPF Communication
- [ ] Implement message listener in background script for WPF commands
- [ ] Create `SelectElement(options)` message handler
  - Activates content script in active tab
  - Prepares UI for selection
  - Waits for user selection
  - Sends confirmed selector back to WPF
- [ ] Add timeout handling (e.g., 5-minute idle → close selection mode)
- [ ] Add user-driven cancellation via UI button or ESC key
- [ ] Return structured response: `{ cssSelector, xpathSelector, elementInfo }`

**Deliverables:**
- `/src/background.js` extensions with full WPF command handling
- Message response schema (selector + metadata)
- Cancellation and timeout logic
- Success/error responses sent back to WPF

---

### Phase 7: Error Handling & Edge Cases
- [ ] Handle elements inside iframes (include iframe selector in result)
- [ ] Handle shadow DOM elements (use `>>>` notation)
- [ ] Handle dynamic content (warn if element removed before confirmation)
- [ ] Handle form inputs and special elements (checkbox, radio, select)
- [ ] Handle pseudo-elements (::before, ::after)
- [ ] Test with pages using frameworks (React, Vue, etc) where DOM is dynamic
- [ ] Add user-friendly error messages to popup

**Deliverables:**
- Error handling logic for common problematic patterns
- Edge case test cases and fixes
- User-facing error messages in popup
- Logging for debugging difficult cases

---

### Phase 8: Documentation & Deployment
- [ ] Create extension README with installation instructions
- [ ] Document native messaging protocol (message format, examples)
- [ ] Create WPF integration guide
  - How to register AllItems.Browser.AddIn in Windows registry
  - How to call SelectBrowserElement() method
  - Expected message format and response format
- [ ] Provide example HTML test pages for selector validation
- [ ] Create troubleshooting guide
- [ ] Add inline code comments for future maintenance

**Deliverables:**
- `/docs/README.md` – Extension overview and quick start
- `/docs/NATIVE-MESSAGING.md` – Protocol specification
- `/docs/WPF-INTEGRATION.md` – Integration guide with code examples
- `/docs/TROUBLESHOOTING.md` – Common issues and solutions
- Example test HTML files in `/examples/`
- Code comments throughout codebase

---

## Acceptance Criteria

### Functional Requirements
- [x] Extension successfully installs in Chrome/Edge/Chromium browsers
- [x] User can click "Start Selection" and choose an element on any webpage
- [x] Extension generates both CSS and XPath selectors for the chosen element
- [x] Generated selectors uniquely identify the element (no false positives)
- [x] When duplicates exist (same ID/class), ancestor chain is added automatically
- [x] User can confirm selection and selector is sent to WPF via native messaging
- [x] WPF receives the selector data (cssSelector, xpathSelector, elementInfo)
- [x] User can cancel selection at any time using button or keyboard (ESC)

### Technical Requirements
- [x] Native messaging communication between WPF and extension is bidirectional
- [x] Extension respects Chromium extension security policies (CSP, manifest v3)
- [x] Content scripts properly handle iframes and shadow DOM elements
- [x] Code is modular, maintainable, and follows ES6+ standards
- [x] All message exchanges are logged for debugging

### Quality & Testing
- [x] Selector engine tested with diverse HTML structures (forms, tables, nested, dynamic)
- [x] Extension tested across Chrome/Edge with different websites
- [x] No console errors or security warnings
- [x] Documentation is complete and easy to follow

### Edge Cases
- [x] Elements inside multiple nested iframes
- [x] Elements inside shadow DOM
- [x] Dynamic DOM changes before confirmation
- [x] Special elements (inputs, selects, buttons, links)
- [x] Pseudo-elements and computed styles

---

## Technical Stack

| Layer | Technology |
|-------|------------|
| **Extension Runtime** | Manifest v3 (Chrome/Edge) |
| **Content Scripts** | Vanilla JavaScript (ES6+) |
| **Build Tool** | Webpack or esbuild |
| **Communication** | Chrome Native Messaging API |
| **Testing** | Jest + DOM testing libraries |
| **VCS** | Git |

---

## Open Questions / Assumptions

### Assumptions Made
1. **WPF Integration Point**: Assumes WPF application already has a method stub or integration point ready to receive messages from the extension.
2. **Windows Registry**: Assumes a Windows machine where extension host manifest will be registered for native messaging.
3. **Chromium Browser**: Assumes Chrome, Edge, Brave, or similar Chromium-based browser is installed and used.
4. **User Consent**: Users understand that clicking elements in the browser while selection is active will trigger selection (no confirmation dialog before starting).

### Questions That May Arise During Implementation
1. **XPath Fragility**: XPath can break with minor DOM changes. Should we add a "robustness score" to selectors?
2. **Selector Validation Timeout**: How long should we wait for a selector to be validated? 5 seconds per element?
3. **Caching**: Should the extension cache recently selected elements/selectors for faster re-selection?
4. **Performance**: On very large pages (1000+ elements), how fast does selector generation need to complete?
5. **Localization**: Should error messages and UI be localized for different languages?
6. **Browser API Coverage**: Are all required Chromium extension APIs available in the target browser versions?

---

## Next Steps

1. **Review & Approve Plan**: Confirm the approach aligns with your vision and constraints.
2. **Begin Phase 1**: Set up project structure and initialize the extension manifest.
3. **Begin Phase 2**: Build the selector engine core in parallel with Phase 1.
4. **Iterative Testing**: As each phase completes, test against real websites and refine edge case handling.

---

## Notes

- **Modularity First**: Each phase produces a working component; later phases integrate and enhance.
- **Testing Discipline**: Write tests as you go; don't defer testing to the end.
- **Documentation**: Maintain clear docs so future maintainers understand design decisions.
- **Incremental Integration**: Once the selector engine works (Phase 2), integrate content scripts (Phase 3) to validate real-world behavior before completing messaging (Phase 4).
