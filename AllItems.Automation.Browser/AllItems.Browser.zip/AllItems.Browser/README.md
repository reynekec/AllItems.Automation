# Selector Demo (WPF Only)

This repository now contains only the WPF demo app.

## What Is Included

- WPF app project: examples/SelectorDemo.Wpf
- Visual Studio solution: AllItems.Browser.sln
- Script to run the app: run-wpf.ps1

## Run

Use either:

```powershell
dotnet run --project examples/SelectorDemo.Wpf/SelectorDemo.Wpf.csproj
```

or:

```powershell
./run-wpf.ps1
```

## Build

```powershell
dotnet build examples/SelectorDemo.Wpf/SelectorDemo.Wpf.csproj
```

## Notes

- Browser add-in and native-host integration code has been removed.
- The app uses in-app WebView2 element selection only.
